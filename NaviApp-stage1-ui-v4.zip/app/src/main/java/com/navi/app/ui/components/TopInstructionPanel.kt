package com.navi.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.navi.app.ui.theme.HudColors

/**
 * The whole HUD is a fixed instrument cluster, not a document — icon and
 * widget POSITIONS must stay LTR (arrow on the left, sign on the right,
 * exactly like the reference), while only the Farsi TEXT inside renders
 * right-to-left. So the outer Row is forced to Ltr, and only Text
 * composables get RTL treatment individually.
 */
@Composable
fun TopInstructionPanel(
    distanceMeters: Int,
    nextRoadName: String,
    highlightWord: String,
    etaTime: String,
    remainingKm: String,
    speedLimit: Int,
    modifier: Modifier = Modifier,
    onClose: () -> Unit = {},
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = modifier
                .fillMaxWidth()
                .background(HudColors.PanelSurface, shape = RoundedCornerShape(28.dp))
                .border(1.dp, HudColors.PanelBorder, RoundedCornerShape(28.dp))
                .padding(horizontal = 18.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Custom hand-drawn turn arrow — always leftmost, matches reference shape
            TurnArrowIcon(color = HudColors.RouteOrange, size = 44.dp)
            Spacer(Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1.3f)) {
                Text(
                    text = "$distanceMeters متر",
                    color = HudColors.TextPrimary,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Bold,
                    textDirection = TextDirection.Rtl
                )
                RoadNameInline(prefix = "به سمت ", highlight = highlightWord, suffix = " $nextRoadName")
            }

            InfoColumn(value = etaTime, label = "زمان رسیدن", isClock = true)
            Spacer(Modifier.width(16.dp))
            InfoColumn(value = remainingKm, label = "مسافت باقیمانده", isClock = false)
            Spacer(Modifier.width(16.dp))

            SpeedLimitSign(speedLimit)
            Spacer(Modifier.width(6.dp))
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.Close, contentDescription = "Close", tint = HudColors.SignRed, modifier = Modifier.size(26.dp))
            }
        }
    }
}

@Composable
private fun RoadNameInline(prefix: String, highlight: String, suffix: String) {
    // Single Text with RTL direction so the Farsi phrase reads correctly
    // as one continuous line instead of being split into scrambled Row children.
    Text(
        text = buildAnnotatedFarsiRoad(prefix, highlight, suffix),
        fontSize = 15.sp,
        textDirection = TextDirection.Rtl
    )
}

@Composable
private fun buildAnnotatedFarsiRoad(
    prefix: String,
    highlight: String,
    suffix: String
): androidx.compose.ui.text.AnnotatedString {
    return androidx.compose.ui.text.buildAnnotatedString {
        withStyle(androidx.compose.ui.text.SpanStyle(color = HudColors.TextSecondary)) {
            append(prefix)
        }
        withStyle(
            androidx.compose.ui.text.SpanStyle(
                color = HudColors.SignRed,
                fontWeight = FontWeight.Bold
            )
        ) {
            append(highlight)
        }
        withStyle(androidx.compose.ui.text.SpanStyle(color = HudColors.TextSecondary)) {
            append(suffix)
        }
    }
}

@Composable
private fun InfoColumn(value: String, label: String, isClock: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (isClock) {
                ClockIcon(size = 16.dp, color = HudColors.TextSecondary)
            } else {
                StopwatchIcon(size = 16.dp, color = HudColors.TextSecondary)
            }
            Spacer(Modifier.width(5.dp))
            Text(text = value, color = HudColors.TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.Medium)
        }
        Text(
            text = label,
            color = HudColors.TextMuted,
            fontSize = 11.sp,
            textDirection = TextDirection.Rtl
        )
    }
}

@Composable
fun SpeedLimitSign(limit: Int, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(52.dp)
            .background(Color.White, CircleShape)
            .border(5.dp, HudColors.SignRed, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(text = limit.toString(), color = Color.Black, fontSize = 18.sp, fontWeight = FontWeight.Black)
    }
}
