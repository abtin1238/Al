package com.navi.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.PinDrop
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.navi.app.ui.components.*
import com.navi.app.ui.theme.HudColors

@Composable
fun NavigationDashboardScreen() {
    var heading by remember { mutableFloatStateOf(35f) }

    Box(
        modifier = Modifier
            .fillMaxSize()
    ) {
        // Map layer (stage 1: procedural placeholder; swapped for OSM later)
        PlaceholderMapCanvas(modifier = Modifier.fillMaxSize())

        // Car marker, positioned near bottom-center like the reference
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 210.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            CarMarker2D()
        }

        // Street name pills over the map
        StreetNamePill(
            text = "بلوار میرداماد",
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 16.dp, top = 340.dp)
        )
        StreetNamePill(
            text = "بلوار شهید همت",
            modifier = Modifier
                .align(Alignment.Center)
                .padding(start = 210.dp, top = -20.dp)
        )
        StreetNamePill(
            text = "اتوبان مدرس",
            modifier = Modifier
                .align(Alignment.Center)
                .padding(start = 60.dp, top = 260.dp)
        )
        StreetNamePill(
            text = "پارک ملت",
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 8.dp, top = 300.dp)
        )

        // Next-turn banner, upper area
        NextTurnBanner(
            text = "شیخ بهایی شمالی",
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 170.dp)
        )

        // Top instruction panel
        TopInstructionPanel(
            distanceMeters = 350,
            nextRoadName = "بهایی",
            highlightWord = "شیخ",
            etaTime = "22:47",
            remainingKm = "7.2 km",
            speedLimit = 80,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(horizontal = 12.dp, vertical = 12.dp)
        )

        // Right side circular controls: compass, pin/save-location, recenter arrow
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            CompassWidget(headingDegrees = heading)
            CircleControlButton(icon = Icons.Filled.PinDrop)
            CircleControlButton(icon = Icons.Filled.MyLocation, tint = HudColors.RouteOrange)
        }

        // Mini speedometer, bottom-left
        MiniSpeedWidget(
            speedKmh = 70,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 12.dp, bottom = 96.dp)
        )

        // Bottom HUD bar
        BottomHudBar(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 12.dp, vertical = 12.dp)
        )
    }
}
