package com.navi.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.navi.app.ui.screens.NavigationDashboardScreen
import com.navi.app.ui.theme.HudColors
import com.navi.app.ui.theme.NaviAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NaviAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = HudColors.Background
                ) {
                    NavigationDashboardScreen()
                }
            }
        }
    }
}
