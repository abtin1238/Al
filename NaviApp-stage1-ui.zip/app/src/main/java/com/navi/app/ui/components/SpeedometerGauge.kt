package com.navi.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.navi.app.ui.theme.HudColors
import kotlin.math.cos
import kotlin.math.sin

/**
 * Analog-style speed dial matching the reference asset:
 * 0..240 km/h, ~250 degree sweep, green -> yellow -> orange -> red gradient arc,
 * tick marks + labels every 20 km/h, no needle, digital number rendered by caller.
 */
@Composable
fun SpeedometerGauge(
    modifier: Modifier = Modifier,
    maxSpeed: Int = 240,
    startAngle: Float = 145f,   // degrees, 0 = 3 o'clock, clockwise
    sweepAngle: Float = 250f,
) {
    Canvas(modifier = modifier.size(320.dp)) {
        val strokeWidth = size.minDimension * 0.045f
        val radius = (size.minDimension - strokeWidth) / 2f
        val center = Offset(size.width / 2f, size.height / 2f)

        // Gradient arc track
        val arcBrush = Brush.sweepGradient(
            colors = listOf(
                HudColors.SpeedGreen,
                HudColors.SpeedGreen,
                HudColors.SpeedYellow,
                HudColors.SpeedOrange,
                HudColors.SpeedRed,
                HudColors.SpeedRed,
            ),
            center = center
        )

        drawArc(
            brush = arcBrush,
            startAngle = startAngle,
            sweepAngle = sweepAngle,
            useCenter = false,
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
            topLeft = Offset(center.x - radius, center.y - radius),
            size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2)
        )

        // Ticks + labels
        val majorStep = 20
        val minorTicksPerMajor = 4
        val totalMajor = maxSpeed / majorStep
        val tickOuterR = radius + strokeWidth * 0.75f
        val tickInnerRMajor = radius - strokeWidth * 0.95f
        val tickInnerRMinor = radius - strokeWidth * 0.55f

        for (i in 0..totalMajor * minorTicksPerMajor) {
            val fraction = i.toFloat() / (totalMajor * minorTicksPerMajor)
            val angleDeg = startAngle + sweepAngle * fraction
            val angleRad = Math.toRadians(angleDeg.toDouble())
            val isMajor = i % minorTicksPerMajor == 0

            val outer = Offset(
                center.x + tickOuterR * cos(angleRad).toFloat(),
                center.y + tickOuterR * sin(angleRad).toFloat()
            )
            val inner = Offset(
                center.x + (if (isMajor) tickInnerRMajor else tickInnerRMinor) * cos(angleRad).toFloat(),
                center.y + (if (isMajor) tickInnerRMajor else tickInnerRMinor) * sin(angleRad).toFloat()
            )

            drawLine(
                color = Color.White.copy(alpha = if (isMajor) 0.9f else 0.5f),
                start = inner,
                end = outer,
                strokeWidth = if (isMajor) 4.5f else 2.2f,
                cap = StrokeCap.Round
            )

            if (isMajor) {
                val labelR = tickInnerRMajor - strokeWidth * 0.9f
                val labelPos = Offset(
                    center.x + labelR * cos(angleRad).toFloat(),
                    center.y + labelR * sin(angleRad).toFloat()
                )
                val speedValue = (majorStep * (i / minorTicksPerMajor))
                drawContext.canvas.nativeCanvas.apply {
                    val paint = android.graphics.Paint().apply {
                        color = android.graphics.Color.argb(230, 230, 230, 235)
                        textSize = strokeWidth * 0.85f
                        textAlign = android.graphics.Paint.Align.CENTER
                        isAntiAlias = true
                        typeface = android.graphics.Typeface.create(
                            android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD
                        )
                    }
                    drawText(
                        speedValue.toString(),
                        labelPos.x,
                        labelPos.y + paint.textSize * 0.33f,
                        paint
                    )
                }
            }
        }
    }
}

@Composable
fun SpeedometerWithReadout(
    speedKmh: Int,
    modifier: Modifier = Modifier,
    maxSpeed: Int = 240,
) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        SpeedometerGauge(maxSpeed = maxSpeed)
        Box(
            modifier = Modifier.size(96.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = speedKmh.toString(),
                color = HudColors.TextPrimary,
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
