package com.navi.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.navi.app.ui.theme.HudColors
import kotlin.math.cos
import kotlin.math.sin

/**
 * Compact bottom-left speedometer badge: quarter/partial arc with digital
 * speed centered, matching the small widget in the main dashboard screenshot.
 */
@Composable
fun MiniSpeedWidget(
    speedKmh: Int,
    modifier: Modifier = Modifier,
    maxSpeed: Int = 240,
    size: androidx.compose.ui.unit.Dp = 160.dp,
) {
    Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.size(size)) {
            val strokeWidth = this.size.minDimension * 0.09f
            val radius = (this.size.minDimension - strokeWidth) / 2f
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val startAngle = 145f
            val sweepAngle = 250f

            val arcBrush = Brush.sweepGradient(
                colors = listOf(
                    HudColors.SpeedGreen,
                    HudColors.SpeedGreen,
                    HudColors.SpeedYellow,
                    HudColors.SpeedOrange,
                    HudColors.SpeedRed,
                    HudColors.SpeedRed,
                ),
                center = center
            )

            drawArc(
                brush = arcBrush,
                startAngle = startAngle,
                sweepAngle = sweepAngle,
                useCenter = false,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                topLeft = Offset(center.x - radius, center.y - radius),
                size = Size(radius * 2, radius * 2)
            )

            // sparse major ticks only, to keep it legible at small size
            val majorStep = 40
            val totalMajor = maxSpeed / majorStep
            val tickOuterR = radius + strokeWidth * 0.7f
            val tickInnerR = radius - strokeWidth * 0.9f

            for (i in 0..totalMajor) {
                val fraction = i.toFloat() / totalMajor
                val angleDeg = startAngle + sweepAngle * fraction
                val angleRad = Math.toRadians(angleDeg.toDouble())

                val outer = Offset(
                    center.x + tickOuterR * cos(angleRad).toFloat(),
                    center.y + tickOuterR * sin(angleRad).toFloat()
                )
                val inner = Offset(
                    center.x + tickInnerR * cos(angleRad).toFloat(),
                    center.y + tickInnerR * sin(angleRad).toFloat()
                )
                drawLine(
                    color = Color.White.copy(alpha = 0.85f),
                    start = inner,
                    end = outer,
                    strokeWidth = 3f,
                    cap = StrokeCap.Round
                )
            }
        }

        Box(contentAlignment = Alignment.Center) {
            Text(
                text = speedKmh.toString(),
                color = HudColors.TextPrimary,
                fontSize = (size.value * 0.22f).sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
