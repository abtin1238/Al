package com.navi.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.TurnLeft
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.navi.app.ui.theme.HudColors

@Composable
fun TopInstructionPanel(
    distanceMeters: Int,
    nextRoadName: String,
    highlightWord: String,
    etaTime: String,
    remainingKm: String,
    speedLimit: Int,
    modifier: Modifier = Modifier,
    onClose: () -> Unit = {},
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(HudColors.PanelSurface, shape = RoundedCornerShape(24.dp))
            .border(1.dp, HudColors.PanelBorder, RoundedCornerShape(24.dp))
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Turn arrow
        Icon(
            imageVector = Icons.Filled.TurnLeft,
            contentDescription = null,
            tint = HudColors.RouteOrange,
            modifier = Modifier.size(40.dp)
        )
        Spacer(Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1.2f)) {
            Text(
                text = "$distanceMeters ${"متر"}",
                color = HudColors.TextPrimary,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            RoadNameInline(prefix = "به سمت ", highlight = highlightWord, suffix = " $nextRoadName")
        }

        InfoColumn(icon = Icons.Filled.Schedule, value = etaTime, label = "زمان رسیدن")
        Spacer(Modifier.width(14.dp))
        InfoColumn(icon = Icons.Filled.Timer, value = remainingKm, label = "مسافت باقیمانده")
        Spacer(Modifier.width(14.dp))

        SpeedLimitSign(speedLimit)
        Spacer(Modifier.width(4.dp))
        IconButton(onClick = onClose) {
            Icon(Icons.Filled.Close, contentDescription = "Close", tint = HudColors.SignRed)
        }
    }
}

@Composable
private fun RoadNameInline(prefix: String, highlight: String, suffix: String) {
    Row {
        Text(text = prefix, color = HudColors.TextSecondary, fontSize = 15.sp)
        Text(text = highlight, color = HudColors.SignRed, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text(text = suffix, color = HudColors.TextSecondary, fontSize = 15.sp)
    }
}

@Composable
private fun InfoColumn(icon: androidx.compose.ui.graphics.vector.ImageVector, value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = HudColors.TextSecondary, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(text = value, color = HudColors.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        }
        Text(text = label, color = HudColors.TextMuted, fontSize = 11.sp)
    }
}

@Composable
fun SpeedLimitSign(limit: Int, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(52.dp)
            .background(Color.White, CircleShape)
            .border(5.dp, HudColors.SignRed, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(text = limit.toString(), color = Color.Black, fontSize = 18.sp, fontWeight = FontWeight.Black)
    }
}
