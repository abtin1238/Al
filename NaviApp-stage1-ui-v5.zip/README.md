# NaviApp — مرحله ۱: UI کامل

اپلیکیشن مسیریاب آفلاین (Kotlin + Jetpack Compose + Material 3). این مخزن به‌صورت
مرحله‌ای ساخته می‌شود؛ **مرحله فعلی فقط رابط کاربری (UI)** است، دقیقاً بر اساس
تصاویر مرجع، بدون نقشه واقعی، مسیریابی، یا مدل سه‌بعدی.

## وضعیت فعلی (Stage 1 — UI)

پیاده‌سازی شده:
- پنل بالا: فلش پیچ، فاصله، زمان رسیدن، مسافت باقیمانده، تابلوی محدودیت سرعت، دکمه بستن
- بنر مسیر بعدی (Next-turn banner)
- پیل‌های نام خیابان روی نقشه
- سرعت‌سنج اصلی دایره‌ای (۰ تا ۲۴۰، گرادیان سبز→زرد→نارنجی→قرمز) — `SpeedometerGauge.kt`
- ویجت سرعت کوچک گوشه پایین-چپ — `MiniSpeedWidget.kt`
- قطب‌نمای چرخان — `CompassWidget.kt`
- دکمه‌های دایره‌ای کناری (قطب‌نما، مکان ذخیره‌شده، موقعیت من)
- نوار پایین: مسیر / ذخیره / جستجو / صدا / تنظیمات
- نشانگر خودروی ۲بعدی ساده (بعداً با مدل GLB جایگزین می‌شود)
- پس‌زمینه نقشه موقت (Canvas رویه‌ای با گرادیان مسیر نارنجی) — جایگزین موقت نقشه واقعی
- پشتیبانی دوزبانه (fa/en) در `res/values` و `res/values-fa`

## ساختار پروژه

```
NaviApp/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/navi/app/
│       │   ├── MainActivity.kt
│       │   └── ui/
│       │       ├── theme/Theme.kt
│       │       ├── components/   (Gauge, Compass, Pills, Buttons, Bottom bar, Car marker, Map placeholder)
│       │       └── screens/NavigationDashboardScreen.kt
│       └── res/values(-fa)/strings.xml, themes.xml
├── .github/workflows/android-build.yml   (CI: assembleDebug + آپلود APK)
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

## بیلد کردن

**در Android Studio (Hedgehog+):** پوشه `NaviApp` را باز کنید؛ Gradle sync خودکار
انجام می‌شود (وابستگی به اینترنت برای دانلود Gradle 8.7 و AGP 8.5 دارد).

**در GitHub Actions:** هر push به `main` باعث اجرای workflow می‌شود که خودش
`gradle wrapper` را می‌سازد و APK دیباگ را به‌عنوان artifact آپلود می‌کند.

> توجه: فایل `gradlew` موجود در ریشه یک fallback ساده است که به `gradle` نصب‌شده
> سیستم متکی است. CI به‌صورت خودکار wrapper رسمی (jar + gradlew واقعی) را
> با `gradle wrapper --gradle-version 8.7` می‌سازد، که روش استاندارد و قابل‌اعتماد است.

## مراحل بعدی (پس از تایید UI)

1. **نقشه آفلاین با OSM** — رندر تایل با osmdroid یا MapLibre Native + مدیریت دانلود/کش تایل
2. **مسیریابی کاملاً آفلاین** — یکپارچه‌سازی موتور مسیریابی (Valhalla/GraphHopper آفلاین) روی داده‌های OSM محلی
3. **جستجوی آفلاین** — ایندکس آدرس/POI محلی (مثلاً با Photon آفلاین یا ایندکس سفارشی)
4. **ذخیره مکان‌ها** — پایگاه‌داده محلی (Room) برای مکان‌های ذخیره‌شده و مسیرهای اخیر
5. **راهنمای صوتی (TTS)** — Android TextToSpeech با پشتیبانی fa/en، هماهنگ با دستورالعمل‌های پیچ
6. **حالت سه‌بعدی و رانندگی** — تغییر دوربین + صحنه سه‌بعدی (Filament/SceneView) با مدل GLB خودرو، فعال با دکمه زیر GPS
7. **چند مدل خودروی سه‌بعدی قابل انتخاب** — شامل مدل اولیه «پیکان» سه‌بعدی
8. **قطب‌نمای واقعی** — اتصال به `SensorManager` (accelerometer + magnetometer) به‌جای مقدار شبیه‌سازی‌شده فعلی

هر مرحله در یک PR/commit جدا اضافه می‌شود تا لایه UI فعلی دست‌نخورده بماند.
