package com.navi.app.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.navi.app.R
import com.navi.app.ui.theme.HudColors

/**
 * Compact bottom-left speedometer badge. Uses the same dial artwork provided
 * by the user (speedometer_dial.png) scaled down, with the digital speed
 * number overlaid in the center — matching the small widget in the reference
 * dashboard screenshot.
 */
@Composable
fun MiniSpeedWidget(
    speedKmh: Int,
    modifier: Modifier = Modifier,
    maxSpeed: Int = 240,
    size: androidx.compose.ui.unit.Dp = 160.dp,
) {
    Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
        Image(
            painter = painterResource(id = R.drawable.speedometer_dial),
            contentDescription = "Speedometer",
            modifier = Modifier.size(size),
            contentScale = ContentScale.Fit
        )
        Text(
            text = speedKmh.toString(),
            color = HudColors.TextPrimary,
            fontSize = (size.value * 0.22f).sp,
            fontWeight = FontWeight.Bold
        )
    }
}
