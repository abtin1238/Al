package com.navi.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp

/** Thin-outline analog clock icon, matching the small ETA icon in the reference. */
@Composable
fun ClockIcon(size: Dp, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.size(size)) {
        val r = this.size.minDimension / 2f
        val center = Offset(this.size.width / 2f, this.size.height / 2f)
        val stroke = r * 0.16f

        drawCircle(color = color, radius = r - stroke / 2f, style = Stroke(width = stroke))
        // hour hand
        drawLine(
            color = color,
            start = center,
            end = Offset(center.x, center.y - r * 0.5f),
            strokeWidth = stroke * 0.8f,
            cap = StrokeCap.Round
        )
        // minute hand
        drawLine(
            color = color,
            start = center,
            end = Offset(center.x + r * 0.4f, center.y),
            strokeWidth = stroke * 0.8f,
            cap = StrokeCap.Round
        )
    }
}

/** Thin-outline stopwatch icon, matching the small remaining-distance icon in the reference. */
@Composable
fun StopwatchIcon(size: Dp, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.size(size)) {
        val r = this.size.minDimension * 0.42f
        val center = Offset(this.size.width / 2f, this.size.height / 2f + this.size.height * 0.06f)
        val stroke = r * 0.18f

        drawCircle(color = color, radius = r, style = Stroke(width = stroke))
        // top button
        drawLine(
            color = color,
            start = Offset(center.x, center.y - r - stroke),
            end = Offset(center.x, center.y - r - stroke * 2.2f),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
        // needle
        drawLine(
            color = color,
            start = center,
            end = Offset(center.x + r * 0.4f, center.y - r * 0.4f),
            strokeWidth = stroke * 0.7f,
            cap = StrokeCap.Round
        )
    }
}
