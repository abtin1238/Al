package com.navi.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.dp

/**
 * Simple top-down 2D car marker with glowing taillights, used in normal
 * (2D) driving mode. Replaced by the 3D GLB model when 3D mode is toggled.
 */
@Composable
fun CarMarker2D(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.size(64.dp, 110.dp)) {
        val w = size.width
        val h = size.height

        val bodyPath = Path().apply {
            addRoundRect(
                RoundRect(
                    rect = androidx.compose.ui.geometry.Rect(
                        Offset(w * 0.12f, h * 0.05f),
                        Size(w * 0.76f, h * 0.9f)
                    ),
                    cornerRadius = CornerRadius(w * 0.3f, w * 0.3f)
                )
            )
        }
        drawPath(bodyPath, color = Color(0xFF1C1C1F))

        // windshield
        drawRoundRect(
            color = Color(0xFF3A3A40),
            topLeft = Offset(w * 0.22f, h * 0.16f),
            size = Size(w * 0.56f, h * 0.22f),
            cornerRadius = CornerRadius(w * 0.12f, w * 0.12f)
        )

        // taillights glow (bottom, since car faces "up" the route)
        drawRoundRect(
            color = Color(0xFFE23B3B),
            topLeft = Offset(w * 0.16f, h * 0.82f),
            size = Size(w * 0.2f, h * 0.08f),
            cornerRadius = CornerRadius(4f, 4f)
        )
        drawRoundRect(
            color = Color(0xFFE23B3B),
            topLeft = Offset(w * 0.64f, h * 0.82f),
            size = Size(w * 0.2f, h * 0.08f),
            cornerRadius = CornerRadius(4f, 4f)
        )
    }
}
