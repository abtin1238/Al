package com.navi.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.PinDrop
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.navi.app.ui.components.*
import com.navi.app.ui.theme.HudColors

/**
 * Full HUD dashboard. The whole tree is forced to LayoutDirection.Ltr because
 * this is a fixed instrument cluster (arrow always top-left, sign always
 * top-right, side controls always on the right) — it must NOT mirror when
 * the system locale is Farsi. Only the Farsi TEXT inside individual
 * components is rendered RTL (see TextDirection.Rtl in each component).
 */
@Composable
fun NavigationDashboardScreen() {
    val heading = remember { mutableFloatStateOf(35f) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(modifier = Modifier.fillMaxSize()) {

            // ---- Map layer (stage 1 placeholder) ----
            PlaceholderMapCanvas(modifier = Modifier.fillMaxSize())

            // Car marker, fixed near bottom-center of the map area
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 300.dp),
                contentAlignment = Alignment.BottomCenter
            ) {
                CarMarker2D()
            }

            // ---- Street name pills (absolute positions matching reference) ----
            StreetNamePill(
                text = "بلوار میرداماد",
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(x = 16.dp, y = 430.dp)
            )
            StreetNamePill(
                text = "بلوار شهید همت",
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(x = 220.dp, y = 430.dp)
            )
            StreetNamePill(
                text = "اتوبان مدرس",
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(x = 155.dp, y = 660.dp)
            )
            StreetNamePill(
                text = "پارک ملت",
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(x = 250.dp, y = 700.dp)
            )

            // ---- Next-turn banner ----
            NextTurnBanner(
                text = "شیخ بهایی شمالی",
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 155.dp)
            )

            // ---- Top instruction panel ----
            TopInstructionPanel(
                distanceMeters = 350,
                nextRoadName = "بهایی",
                highlightWord = "شیخ",
                etaTime = "22:47",
                remainingKm = "7.2 km",
                speedLimit = 80,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(horizontal = 12.dp, vertical = 12.dp)
            )

            // ---- Right side circular controls ----
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 16.dp)
                    .offset(y = (-40).dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CompassWidget(headingDegrees = heading.floatValue)
                CircleControlButton(icon = Icons.Filled.PinDrop)
                CircleControlButton(icon = Icons.Filled.MyLocation, tint = HudColors.RouteOrange)
            }

            // ---- Mini speedometer, bottom-left ----
            MiniSpeedWidget(
                speedKmh = 70,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = 12.dp, bottom = 96.dp)
            )

            // ---- Bottom HUD bar ----
            BottomHudBar(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 12.dp, vertical = 12.dp)
            )
        }
    }
}
