package com.navi.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.navi.app.ui.theme.HudColors

/**
 * Compass control: rotates its needle opposite to device heading so it always
 * points true north, matching the top-right circular control in the reference.
 *
 * @param headingDegrees current device heading in degrees (0 = North, clockwise)
 */
@Composable
fun CompassWidget(
    headingDegrees: Float,
    modifier: Modifier = Modifier,
    size: androidx.compose.ui.unit.Dp = 56.dp,
) {
    Canvas(
        modifier = modifier
            .size(size)
            .background(HudColors.PanelSurface, CircleShape)
            .border(1.dp, HudColors.PanelHighlight, CircleShape)
    ) {
        rotate(degrees = -headingDegrees) {
            val cx = this.size.width / 2f
            val cy = this.size.height / 2f
            val len = this.size.minDimension * 0.36f

            // North half - red
            val northPath = Path().apply {
                moveTo(cx, cy - len)
                lineTo(cx - len * 0.28f, cy)
                lineTo(cx + len * 0.28f, cy)
                close()
            }
            drawPath(northPath, color = HudColors.SignRed)

            // South half - light gray
            val southPath = Path().apply {
                moveTo(cx, cy + len)
                lineTo(cx - len * 0.28f, cy)
                lineTo(cx + len * 0.28f, cy)
                close()
            }
            drawPath(southPath, color = Color(0xFFCFCFD2))

            drawCircle(color = Color(0xFF1A1A1D), radius = len * 0.18f, center = Offset(cx, cy))
        }
    }
}
