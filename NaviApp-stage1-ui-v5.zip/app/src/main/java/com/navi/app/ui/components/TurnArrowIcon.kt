package com.navi.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Hand-drawn "left turn" instruction arrow matching the exact hook shape from
 * the reference image: a thick rounded stroke that curves down-then-left-then-up
 * into a sharp arrowhead, NOT the generic Material "TurnLeft" glyph.
 */
@Composable
fun TurnArrowIcon(
    modifier: Modifier = Modifier,
    color: Color = Color(0xFFFF7A18),
    size: Dp = 40.dp,
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val strokeW = w * 0.16f

        // Hook body: starts top-right, curves down and to the left, ending
        // pointing left (the "return" stroke of a U-turn/left-turn glyph).
        val body = Path().apply {
            moveTo(w * 0.78f, h * 0.12f)
            cubicTo(
                w * 0.95f, h * 0.30f,
                w * 0.95f, h * 0.68f,
                w * 0.68f, h * 0.72f
            )
            lineTo(w * 0.30f, h * 0.72f)
        }
        drawPath(
            path = body,
            color = color,
            style = Stroke(width = strokeW, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        // Arrowhead at the left end, pointing left-down like the reference
        val head = Path().apply {
            moveTo(w * 0.42f, h * 0.46f)
            lineTo(w * 0.14f, h * 0.72f)
            lineTo(w * 0.42f, h * 0.98f)
            close()
        }
        drawPath(path = head, color = color)
    }
}
