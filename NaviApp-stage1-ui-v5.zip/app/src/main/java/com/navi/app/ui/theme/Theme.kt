package com.navi.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ---- HUD token palette (derived from reference dashboard) ----
object HudColors {
    val Background = Color(0xFF060607)          // near-black chassis background
    val PanelSurface = Color(0xCC101012)         // translucent brushed-metal panel
    val PanelBorder = Color(0xFF2A2A2E)
    val PanelHighlight = Color(0xFF3D3D42)

    val RouteOrange = Color(0xFFFF7A18)          // primary route glow
    val RouteOrangeCore = Color(0xFFFFB25C)

    val TextPrimary = Color(0xFFF3F3F3)
    val TextSecondary = Color(0xFFB6B6BA)
    val TextMuted = Color(0xFF7C7C82)

    val SpeedGreen = Color(0xFF3DDC5B)
    val SpeedYellow = Color(0xFFE7D33B)
    val SpeedOrange = Color(0xFFE8862D)
    val SpeedRed = Color(0xFFE23B3B)

    val SignRed = Color(0xFFD5342B)
    val SignWhite = Color(0xFFFAFAFA)

    val ButtonBlue = Color(0xFF3E8EDE)
    val ButtonGreen = Color(0xFF37C24A)
    val ButtonPurple = Color(0xFF8B5CF6)
}

private val NaviDarkScheme = darkColorScheme(
    background = HudColors.Background,
    surface = HudColors.PanelSurface,
    primary = HudColors.RouteOrange,
    onBackground = HudColors.TextPrimary,
    onSurface = HudColors.TextPrimary,
)

@Composable
fun NaviAppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NaviDarkScheme,
        content = content
    )
}
