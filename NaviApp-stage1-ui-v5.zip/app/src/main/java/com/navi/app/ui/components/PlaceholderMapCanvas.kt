package com.navi.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke

/**
 * Stage-1 placeholder for the map surface: dark city-grid background with a
 * glowing orange route path and a car marker at the bottom, matching the
 * reference screenshot's composition. Real OSM rendering replaces this
 * Canvas entirely in the mapping stage without touching the HUD layer above it.
 */
@Composable
fun PlaceholderMapCanvas(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxSize()) {
        // base near-black ground
        drawRect(color = Color(0xFF08080A))

        // faint street grid
        val gridColor = Color(0xFF17171B)
        val cols = 6
        val rows = 10
        for (i in 0..cols) {
            val x = size.width * i / cols
            drawLine(gridColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 3f)
        }
        for (j in 0..rows) {
            val y = size.height * j / rows
            drawLine(gridColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 3f)
        }

        // route path: gentle S-curve from bottom center up to top center
        val startX = size.width * 0.46f
        val midX = size.width * 0.52f
        val endX = size.width * 0.46f
        val bottomY = size.height * 0.98f
        val topY = size.height * 0.18f

        val routePath = Path().apply {
            moveTo(startX, bottomY)
            cubicTo(
                startX, bottomY * 0.75f,
                midX, bottomY * 0.55f,
                midX, bottomY * 0.4f
            )
            cubicTo(
                midX, bottomY * 0.25f,
                endX, topY * 1.3f,
                endX, topY
            )
        }

        // glow
        drawPath(
            path = routePath,
            brush = Brush.verticalGradient(
                listOf(Color(0xFFFF7A18), Color(0xFFFFB25C))
            ),
            style = Stroke(width = 46f, cap = StrokeCap.Round)
        )
        drawPath(
            path = routePath,
            color = Color(0xFFFF7A18).copy(alpha = 0.35f),
            style = Stroke(width = 80f, cap = StrokeCap.Round)
        )

        // directional chevrons along the path (approximate with dashed overlay)
        drawPath(
            path = routePath,
            color = Color.White.copy(alpha = 0.55f),
            style = Stroke(
                width = 6f,
                cap = StrokeCap.Round,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 22f), 0f)
            )
        )
    }
}
