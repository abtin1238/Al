package com.navi.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.navi.app.ui.theme.HudColors

/** Street-name label pill floating over the map. */
@Composable
fun StreetNamePill(text: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(Color(0xE6141416), RoundedCornerShape(18.dp))
            .border(1.dp, HudColors.PanelHighlight, RoundedCornerShape(18.dp))
            .padding(horizontal = 16.dp, vertical = 9.dp)
    ) {
        Text(
            text = text,
            color = HudColors.TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            textDirection = TextDirection.Rtl
        )
    }
}

/**
 * Next-turn banner pill with arrow icon (e.g. "شیخ بهایی شمالی").
 * In the reference the arrow sits on the RIGHT of the Farsi text (visually),
 * so with the outer Row forced Ltr, the icon is placed last (rightmost slot).
 */
@Composable
fun NextTurnBanner(text: String, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .background(Color(0xE6141416), RoundedCornerShape(26.dp))
            .border(1.dp, HudColors.PanelHighlight, RoundedCornerShape(26.dp))
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = text,
            color = HudColors.TextPrimary,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            textDirection = TextDirection.Rtl
        )
        Spacer(Modifier.width(10.dp))
        TurnArrowIcon(color = HudColors.TextPrimary, size = 22.dp)
    }
}

/** Circular side control button (compass, recenter, current-location arrow). */
@Composable
fun CircleControlButton(
    icon: ImageVector,
    modifier: Modifier = Modifier,
    tint: Color = HudColors.TextPrimary,
    size: Dp = 56.dp,
    onClick: () -> Unit = {},
) {
    Box(
        modifier = modifier
            .size(size)
            .background(HudColors.PanelSurface, CircleShape)
            .border(1.dp, HudColors.PanelHighlight, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(size * 0.45f))
    }
}

/** Bottom navigation bar: Route / Save / Search (center, prominent) / Voice / Settings. */
@Composable
fun BottomHudBar(
    onRoute: () -> Unit = {},
    onSave: () -> Unit = {},
    onSearch: () -> Unit = {},
    onVoice: () -> Unit = {},
    onSettings: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(HudColors.PanelSurface, RoundedCornerShape(28.dp))
            .border(1.dp, HudColors.PanelBorder, RoundedCornerShape(28.dp))
            .padding(horizontal = 12.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        BottomBarItem(icon = Icons.Filled.AltRoute, label = "مسیر", tint = HudColors.ButtonBlue, onClick = onRoute)
        BottomBarItem(icon = Icons.Filled.SaveAlt, label = "ذخیره", tint = HudColors.ButtonGreen, onClick = onSave)

        // Center search button, larger and elevated
        Box(
            modifier = Modifier
                .size(64.dp)
                .background(Color(0xFF1A1A1D), CircleShape)
                .border(2.dp, HudColors.PanelHighlight, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Search, contentDescription = "Search", tint = Color.White, modifier = Modifier.size(28.dp))
        }

        BottomBarItem(icon = Icons.Filled.VolumeUp, label = "صدا", tint = HudColors.RouteOrange, onClick = onVoice)
        BottomBarItem(icon = Icons.Filled.Settings, label = "تنظیمات", tint = HudColors.ButtonPurple, onClick = onSettings)
    }
}

@Composable
private fun BottomBarItem(icon: ImageVector, label: String, tint: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(26.dp))
        Spacer(Modifier.height(4.dp))
        Text(
            text = label,
            color = HudColors.TextSecondary,
            fontSize = 12.sp,
            textDirection = TextDirection.Rtl
        )
    }
}
