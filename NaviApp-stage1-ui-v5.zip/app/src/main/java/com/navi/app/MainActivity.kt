package com.navi.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.navi.app.ui.screens.NavigationDashboardScreen
import com.navi.app.ui.theme.HudColors
import com.navi.app.ui.theme.NaviAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NaviAppTheme {
                // Force Ltr at the very root: this HUD is a fixed instrument
                // cluster (arrow top-left, sign top-right) and must not
                // mirror when the device locale is Farsi (RTL).
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = HudColors.Background
                    ) {
                        NavigationDashboardScreen()
                    }
                }
            }
        }
    }
}
