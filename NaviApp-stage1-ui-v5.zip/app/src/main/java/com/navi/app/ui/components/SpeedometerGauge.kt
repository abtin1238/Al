package com.navi.app.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.navi.app.R
import com.navi.app.ui.theme.HudColors

/**
 * Main speed dial: uses the exact dial artwork provided by the user
 * (res/drawable-nodpi/speedometer_dial.png) as the background — ticks,
 * numbers, and the green->yellow->red gradient arc all come from that image,
 * not hand-drawn Canvas code.
 */
@Composable
fun SpeedometerGauge(
    modifier: Modifier = Modifier,
    maxSpeed: Int = 240, // kept for API compatibility; the image itself is 0..240
) {
    Image(
        painter = painterResource(id = R.drawable.speedometer_dial),
        contentDescription = "Speedometer dial",
        modifier = modifier.size(320.dp),
        contentScale = ContentScale.Fit
    )
}

@Composable
fun SpeedometerWithReadout(
    speedKmh: Int,
    modifier: Modifier = Modifier,
    maxSpeed: Int = 240,
) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        SpeedometerGauge(maxSpeed = maxSpeed)
        Box(
            modifier = Modifier.size(96.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = speedKmh.toString(),
                color = HudColors.TextPrimary,
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
